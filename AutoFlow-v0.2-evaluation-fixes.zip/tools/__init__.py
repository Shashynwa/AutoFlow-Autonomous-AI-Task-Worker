"""Restricted local company tools."""
